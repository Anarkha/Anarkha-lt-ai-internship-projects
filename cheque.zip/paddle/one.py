import os
import numpy as np
import tensorflow as tf
from keras.preprocessing.image import ImageDataGenerator
from keras.applications import MobileNetV2
from keras.models import Model
from keras.layers import Dense, GlobalAveragePooling2D, Dropout
from keras.optimizers import Adam

# Define paths
DATASET_DIR = "D:\\cheque_l&t\\cheque data"
IMG_SIZE = 224
BATCH_SIZE = 32

# Data preparation
datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2,
    rotation_range=20,
    zoom_range=0.2,
    horizontal_flip=True
)

train_gen = datagen.flow_from_directory(
    DATASET_DIR,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='training'
)

val_gen = datagen.flow_from_directory(
    DATASET_DIR,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='binary',
    subset='validation'
)

# Add these print statements to check the number of images found
print(f"Found {train_gen.samples} images belonging to {train_gen.num_classes} classes for training.")
print(f"Found {val_gen.samples} images belonging to {val_gen.num_classes} classes for validation.")

# Load base model
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(IMG_SIZE, IMG_SIZE, 3))
base_model.trainable = False

# Add custom layers
x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dropout(0.3)(x)
output = Dense(1, activation='sigmoid')(x)
model = Model(inputs=base_model.input, outputs=output)

# Compile model
model.compile(optimizer=Adam(learning_rate=0.0001), loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
# Ensure train_gen.samples and val_gen.samples are > 0 before training
if train_gen.samples > 0 and val_gen.samples > 0:
    model.fit(train_gen, validation_data=val_gen, epochs=10)
else:
    print("Error: No images found for training or validation. Please check your dataset directory and structure.")


# Save the trained model
# Only save if training was successful
if train_gen.samples > 0 and val_gen.samples > 0:
    model.save('mobilenet_cheque_classifier.h5')

# Save the trained model
model.save('mobilenet_cheque_classifier.h5')