from paddleocr import PaddleOCR

ocr = PaddleOCR(use_textline_orientation=True, lang='en')

image_path = "D:\\paddlegp\\image2.png"

results = ocr.predict(image_path)

# results is a list with one OCRResult object
ocr_result = results[0]

rec_texts = ocr_result['rec_texts']  # list of text strings
rec_scores = ocr_result['rec_scores']  # list of confidence scores

all_texts = []

for text, score in zip(rec_texts, rec_scores):
    print(f"Text: {text}, Confidence: {score:.2f}")
    all_texts.append(text)

print("\nFull recognized text:")
print("\n".join(all_texts))
