from fastapi import FastAPI, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from transformers import DonutProcessor, VisionEncoderDecoderModel
from PIL import Image
from pdf2image import convert_from_path
from pathlib import Path
import torch
import os

# Initialize Donut model
device = "cuda" if torch.cuda.is_available() else "cpu"
processor = DonutProcessor.from_pretrained("naver-clova-ix/donut-base-finetuned-docvqa", use_fast=False)
model = VisionEncoderDecoderModel.from_pretrained("naver-clova-ix/donut-base-finetuned-docvqa")
model.to(device)

# FastAPI app
app = FastAPI()

# Enable CORS for Streamlit or any frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "✅ Donut OCR API is running. Use POST /donutapi to extract info."}

@app.get("/donutapi")
async def test_donutapi():
    return {"message": "✅ This is the GET test for /donutapi. POST to this endpoint to extract text."}

@app.post("/donutapi", summary="Extract fields using Donut", response_class=JSONResponse)
async def extract_text_donut_upload(
    file: UploadFile = File(...),
    keywords: str = Form(...)
):
    keyword_list = [kw.strip() for kw in keywords.split(",")] if keywords else []

    temp_path = "temp_uploaded_file" + Path(file.filename).suffix.lower()
    contents = await file.read()
    with open(temp_path, "wb") as f:
        f.write(contents)

    try:
        # Detect file type: PDF vs image
        ext = Path(temp_path).suffix.lower()
        if ext == ".pdf":
            images = convert_from_path(temp_path, dpi=150, poppler_path="C:\\poppler-24.08.0\\Library\\bin")
            image = images[0].convert("RGB")
        elif ext in [".png", ".jpg", ".jpeg"]:
            image = Image.open(temp_path).convert("RGB")
        else:
            raise HTTPException(status_code=400, detail="❌ Unsupported file type.")

        # Preprocess image
        pixel_values = processor(image, return_tensors="pt").pixel_values.to(device)
        extracted_info = {}

        for keyword in keyword_list:
            print(f"🔍 Extracting for keyword: {keyword}")
            task_prompt = f"<s_docvqa><s_question>{keyword}</s_question><s_answer>"
            decoder_input_ids = processor.tokenizer(
                task_prompt, add_special_tokens=False, return_tensors="pt"
            ).input_ids.to(device)

            with torch.no_grad():
                outputs = model.generate(
                    pixel_values,
                    decoder_input_ids=decoder_input_ids,
                    max_length=model.decoder.config.max_position_embeddings,
                    pad_token_id=processor.tokenizer.pad_token_id,
                    eos_token_id=processor.tokenizer.eos_token_id,
                )

            sequence = processor.batch_decode(outputs, skip_special_tokens=True)[0]
            sequence = sequence.replace("<s_answer>", "").strip()
            if sequence.lower().startswith(keyword.lower()):
                sequence = sequence[len(keyword):].strip()
            extracted_info[keyword] = sequence

    except Exception as e:
        raise HTTPException(status_code=400, detail=f"❌ Error processing file: {str(e)}")
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

    return {"extracted_info": extracted_info}

# Entry point
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("do:app", host="127.0.0.1", port=8010, reload=True)
