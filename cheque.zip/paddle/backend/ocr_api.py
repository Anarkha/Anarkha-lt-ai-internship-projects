# from fastapi import FastAPI, File, UploadFile
# from fastapi.middleware.cors import CORSMiddleware
# from paddleocr import PaddleOCR
# from typing import List
# import uvicorn

# app = FastAPI()

# # Allow Streamlit app (likely on localhost:8501) to talk to this API
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # For dev, allow all origins; restrict in production
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# ocr = PaddleOCR(use_angle_cls=True, lang='en')

# @app.post("/ocr")
# async def ocr_endpoint(file: UploadFile = File(...)):
#     contents = await file.read()
#     temp_path = "D:\paddlegp\image2.png"
#     with open(temp_path, "wb") as f:
#         f.write(contents)
#     results = ocr.predict(temp_path)
#     texts = results[0]['rec_texts']
#     scores = results[0]['rec_scores']
#     response = [{"text": text, "confidence": score} for text, score in zip(texts, scores)]
#     return {"results": response}

# if __name__ == "__main__":
#     uvicorn.run(app, host="0.0.0.0", port=8000)

from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from paddleocr import PaddleOCR
import cv2
import numpy as np
import uvicorn

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ocr = PaddleOCR(use_angle_cls=True, lang='en')

def preprocess_image_from_bytes(image_bytes, output_path="cleaned_image.png"):
    np_arr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    cv2.imwrite(output_path, binary)
    return output_path

@app.post("/ocr")
async def ocr_endpoint(file: UploadFile = File(...)):
    contents = await file.read()
    cleaned_path = preprocess_image_from_bytes(contents)

    results = ocr.ocr(cleaned_path, cls=True)

    texts = []
    scores = []

    for line in results[0]:
        text, score = line[1]
        texts.append(text)
        scores.append(score)

    confidence_threshold = 0.9
    response = [
        {"text": text, "confidence": score}
        for text, score in zip(texts, scores)
        if score >= confidence_threshold
    ]

    return {"results": response}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
main = app
