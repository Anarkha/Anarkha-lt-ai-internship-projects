import streamlit as st
from paddleocr import PaddleOCR
from pdf2image import convert_from_path
from PIL import Image
import tempfile
import requests
import io

# Initialize PaddleOCR once
ocr = PaddleOCR(use_angle_cls=True, lang='en')

st.set_page_config(page_title="Document AI", layout="centered")
st.title("📄 Document AI – PaddleOCR + Donut + Cheque Classifier")

# Section selection
option = st.radio("Choose Tool:", ['PaddleOCR', 'Donut', 'Cheque Classifier'])

uploaded_file = st.file_uploader("Upload an image or PDF", type=["png", "jpg", "jpeg", "pdf"])

# For Donut: Show keyword input
keyword = ""
if option == 'Donut':
    keyword = st.text_input("🔍 Enter keyword to extract (e.g. Student Name):")

# For Cheque Classifier: Show image
if uploaded_file and option == "Cheque Classifier":
    st.image(uploaded_file, caption="Uploaded Image", use_column_width=True)

# Process when file is uploaded
if uploaded_file:
    images = []

    if uploaded_file.type == "application/pdf":
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_pdf:
                tmp_pdf.write(uploaded_file.read())
                tmp_pdf_path = tmp_pdf.name
            images = convert_from_path(tmp_pdf_path)
        except Exception as e:
            st.error(f"❌ PDF conversion failed: {e}")
            st.stop()
    else:
        image = Image.open(uploaded_file).convert("RGB")
        images = [image]

    # --- PaddleOCR ---
    if option == 'PaddleOCR':
        st.subheader("📝 Extracted Text (PaddleOCR):")
        for img in images:
            with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_img:
                img.save(tmp_img.name)
                result = ocr.ocr(tmp_img.name)
                for line in result:
                    for word_info in line:
                        text = word_info[1][0]
                        st.write(text)

    # --- Donut Keyword Extraction ---
    elif option == 'Donut':
        if keyword.strip() == "":
            st.warning("⚠️ Please enter a keyword.")
        elif st.button("Extract with Donut"):
            uploaded_file.seek(0)
            files = {'file': (uploaded_file.name, uploaded_file.read(), uploaded_file.type)}
            data = {'keywords': keyword}
            try:
                response = requests.post("http://127.0.0.1:8010/donutapi", files=files, data=data)
                if response.status_code == 200:
                    result = response.json()
                    st.success("✅ Extracted Info:")
                    for k, v in result.get("extracted_info", {}).items():
                        st.write(f"**{k}**: {v}")
                else:
                    st.error(f"❌ API Error: {response.status_code} - {response.text}")
            except Exception as e:
                st.error(f"❌ Request failed: {e}")

    # --- Cheque Classification ---
    elif option == 'Cheque Classifier':
        if st.button("Classify"):
            with st.spinner("🔍 Classifying cheque image..."):
                uploaded_file.seek(0)
                try:
                    response = requests.post(
                        "http://127.0.0.1:8012/predictcheque",
                        files={"file": uploaded_file.read()}
                    )
                    if response.status_code == 200:
                        result = response.json()
                        st.success(f"🏷️ Prediction: {result['prediction']}")
                        st.info(f"📊 Confidence: {result['confidence']:.2f}")
                    else:
                        st.error("❌ Classification failed.")
                except Exception as e:
                    st.error(f"❌ Failed to contact API: {e}")
