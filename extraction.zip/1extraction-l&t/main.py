import fitz  # PyMuPDF
import pdfplumber
import camelot
import os

# ---------- Configuration ----------
pdf_path = "D:\\1extraction-l&t\\Liebherr-LTM-1130-operators-manual-21-1686.pdf"  # <-- Replace with your PDF file
output_dir = "output"
text_dir = os.path.join(output_dir, "text")
table_dir = os.path.join(output_dir, "tables")
image_dir = os.path.join(output_dir, "images")

# ---------- Setup output folders ----------
os.makedirs(text_dir, exist_ok=True)
os.makedirs(table_dir, exist_ok=True)
os.makedirs(image_dir, exist_ok=True)

# ---------- 1. Extract Text ----------
print("Extracting text...")
with pdfplumber.open(pdf_path) as pdf:
    for i, page in enumerate(pdf.pages):
        text = page.extract_text()
        if text:
            with open(os.path.join(text_dir, f"page_{i+1}.txt"), "w", encoding="utf-8") as f:
                f.write(text)

# ---------- 2. Extract Tables ----------
print("Extracting tables...")
tables = camelot.read_pdf(pdf_path, pages='all')
for i, table in enumerate(tables):
    table_path = os.path.join(table_dir, f"table_{i+1}.csv")
    table.to_csv(table_path)

# ---------- 3. Extract Images ----------
print("Extracting images...")
pdf_file = fitz.open(pdf_path)
image_count = 0
for page_number in range(len(pdf_file)):
    page = pdf_file[page_number]
    image_list = page.get_images(full=True)

    for img_index, img in enumerate(image_list):
        xref = img[0]
        base_image = pdf_file.extract_image(xref)
        image_bytes = base_image["image"]
        image_ext = base_image["ext"]
        image_path = os.path.join(image_dir, f"image_{page_number+1}_{img_index+1}.{image_ext}")
        with open(image_path, "wb") as image_file:
            image_file.write(image_bytes)
        image_count += 1

print(f"Done! Extracted text from {len(pdf_file)} pages, {len(tables)} tables, and {image_count} images.")
