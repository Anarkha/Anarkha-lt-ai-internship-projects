# import json

# # Function to merge multiple header rows
# def merge_multiline_headers(header_rows):
#     max_cols = max(len(row) for row in header_rows)
#     # Pad shorter rows
#     normalized = [row + [""] * (max_cols - len(row)) for row in header_rows]
#     # Merge by column
#     return [" ".join(parts).strip() for parts in zip(*normalized)]

# # Load the file
# with open('all_structured_pages.json', 'r') as f:
#     json_data = json.load(f)

# # Process all tables/pages
# if "data" in json_data and isinstance(json_data["data"], list):
#     new_data = []

#     for table in json_data["data"]:
#         if isinstance(table, list) and len(table) >= 2 and all(isinstance(row, list) for row in table[:2]):
#             # Merge first two rows as header if applicable
#             merged_header = merge_multiline_headers(table[:2])
#             # Combine merged header with the rest of the table
#             new_table = [merged_header] + table[2:]
#         else:
#             # If no split header, keep as is
#             new_table = table
#         new_data.append(new_table)

#     # Replace data with cleaned version
#     json_data["data"] = new_data

# # Save cleaned version
# with open('cleaned_all_structured_data1.json', 'w') as f:
#     json.dump(json_data, f, indent=4)

# print("✅ All headers processed and saved to 'cleaned_all_structured_data1.json'")

import json

# Load the original JSON file
with open('all_structured_pages.json', 'r') as f:
    json_data = json.load(f)

# Recursive function to remove empty strings from lists
def clean_data(obj):
    if isinstance(obj, list):
        return [clean_data(item) for item in obj if item != ""]
    elif isinstance(obj, dict):
        return {k: clean_data(v) for k, v in obj.items()}
    else:
        return obj

# Clean the entire structure
cleaned_data = clean_data(json_data)

# Save cleaned data to a new file
with open('cleaned_all_structured_data.json', 'w') as f:
    json.dump(cleaned_data, f, indent=4)

print("✅ Cleaned data saved as 'cleaned_all_structured_data.json'")




import json

# Load input data
with open("cleaned_all_structured_data.json", "r", encoding="utf-8") as file:
    input_data = json.load(file)

def merge_header_rows(table):
    if len(table) < 2:
        return table  # Not enough rows to merge

    row1 = table[0]
    row2 = table[1]
    max_len = max(len(row1), len(row2))
    
    # Pad shorter rows with empty strings
    row1 += [""] * (max_len - len(row1))
    row2 += [""] * (max_len - len(row2))

    # Merge both rows
    merged_row = []
    for col1, col2 in zip(row1, row2):
        merged = " ".join(part.strip() for part in [col1, col2] if part.strip())
        merged_row.append(merged)

    return [merged_row] + table[2:]  # Replace first two rows with merged

# Apply to all pages
for page in input_data:
    if "data" in page and isinstance(page["data"], list):
        page["data"] = merge_header_rows(page["data"])

# Save result
with open("1cleaned_structured_data.json", "w", encoding="utf-8") as out_file:
    json.dump(input_data, out_file, indent=2, ensure_ascii=False)

print("✅ Merged headers saved in '1cleaned_structured_data.json'")


import json

# Load cleaned data
with open("cleaned_all_structured_data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Merge any additional header rows into the first one
def smart_merge_headers(table, max_header_lines=3):
    headers_to_merge = table[:max_header_lines]
    if len(headers_to_merge) < 2:
        return table  # Nothing to merge

    max_cols = max(len(row) for row in headers_to_merge)
    normalized = [row + [""] * (max_cols - len(row)) for row in headers_to_merge]

    merged_row = []
    for col_idx in range(max_cols):
        parts = [normalized[row_idx][col_idx].strip() for row_idx in range(len(normalized))]
        cell = " ".join(part for part in parts if part).strip()
        merged_row.append(cell)

    return [merged_row] + table[max_header_lines:]

# Remove trailing empty strings (not padding)
def trim_empty_cells(table):
    return [list(filter(lambda x: x != "", row)) for row in table]

# Apply to all pages
for page in data:
    if "data" in page:
        table = page["data"]
        table = smart_merge_headers(table, max_header_lines=2)
        table = trim_empty_cells(table)
        page["data"] = table

# Save output
with open("final_cleaned_data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)

print("✅ Final cleaned and aligned table saved as 'final_cleaned_data.json'")
