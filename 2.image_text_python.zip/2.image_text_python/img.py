
import easyocr
reader = easyocr.Reader(['en']) 
import fitz  # PyMuPDF
from PIL import Image
import numpy as np
import easyocr
from collections import defaultdict
import os
import csv
import json

# === OCR SETUP ===
reader = easyocr.Reader(['en'])  # Initialize EasyOCR

# === FUNCTIONS ===
def get_top_left_x(bbox):
    return min(point[0] for point in bbox)

def get_top_left_y(bbox):
    return min(point[1] for point in bbox)

def cluster_coords(coords, tolerance=15):
    if not coords:
        return []
    coords = sorted(list(set(coords)))
    clusters = []
    current_cluster = [coords[0]]

    for c in coords[1:]:
        if abs(c - current_cluster[-1]) <= tolerance:
            current_cluster.append(c)
        else:
            clusters.append(int(np.mean(current_cluster)))
            current_cluster = [c]
    if current_cluster:
        clusters.append(int(np.mean(current_cluster)))
    return sorted(list(set(clusters)))

def find_closest_cluster(value, clusters):
    if not clusters:
        return None
    return min(clusters, key=lambda c: abs(c - value))

# === MAIN OCR PROCESSING ===
pdf_path = "C:\image_text_python\Doc_new.pdf"  # Replace with your actual path
doc = fitz.open(pdf_path)

for page_num, page in enumerate(doc):
    pix = page.get_pixmap(dpi=300)
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    img_np = np.array(img)

    results = reader.readtext(img_np)

    if not results:
        print(f"⚠️ No text found on page {page_num + 1}.")
        with open(f"structured_text_page_{page_num + 1}.txt", "w", encoding="utf-8") as f:
            f.write(f"--- Page {page_num + 1} ---\nNo text found.\n")
        continue

    xs = [get_top_left_x(bbox) for bbox, _, _ in results]
    ys = [get_top_left_y(bbox) for bbox, _, _ in results]

    col_clusters = cluster_coords(xs, tolerance=20)
    row_clusters = cluster_coords(ys, tolerance=10)

    grid = defaultdict(list)
    for bbox, text, conf in results:
        x = get_top_left_x(bbox)
        y = get_top_left_y(bbox)
        col = find_closest_cluster(x, col_clusters)
        row = find_closest_cluster(y, row_clusters)

        if col is not None and row is not None:
            grid[(row, col)].append((x, text))

    structured_text = f"--- Page {page_num + 1} ---\n"
    if row_clusters and col_clusters:
        for r in sorted(row_clusters):
            row_texts = []
            for c in sorted(col_clusters):
                cell_texts = grid.get((r, c), [])
                sorted_cell_texts = sorted(cell_texts, key=lambda item: item[0])
                row_texts.append(" ".join([text for _, text in sorted_cell_texts]))
            structured_text += "\t".join(row_texts) + "\n"

    with open(f"structured_text_page_{page_num + 1}.txt", "w", encoding="utf-8") as f:
        f.write(structured_text)

print("✅ Text extraction complete.")

# === EXPORT TO CSV ===
page_range = range(1, len(doc) + 1)

for page_num in page_range:
    txt_file = f"structured_text_page_{page_num}.txt"
    csv_file = f"structured_text_page_{page_num}.csv"

    if not os.path.exists(txt_file):
        continue

    with open(txt_file, "r", encoding="utf-8") as infile:
        lines = [line.strip() for line in infile if line.strip()]
        if lines and lines[0].startswith("--- Page"):
            lines = lines[1:]

    rows = [line.split("\t") for line in lines]

    with open(csv_file, "w", newline='', encoding="utf-8") as outfile:
        writer = csv.writer(outfile)
        writer.writerows(rows)

# === EXPORT TO JSON ===
for page_num in page_range:
    txt_file = f"structured_text_page_{page_num}.txt"
    json_file = f"structured_text_page_{page_num}.json"

    if not os.path.exists(txt_file):
        continue

    with open(txt_file, "r", encoding="utf-8") as infile:
        lines = [line.strip() for line in infile if line.strip()]
        if lines and lines[0].startswith("--- Page"):
            lines = lines[1:]

    data = [line.split("\t") for line in lines]

    with open(json_file, "w", encoding="utf-8") as outfile:
        json.dump(data, outfile, indent=4)

# === COMBINE ALL TO ONE JSON FILE ===
all_data = []
for page_num in page_range:
    txt_file = f"structured_text_page_{page_num}.txt"
    if not os.path.exists(txt_file):
        continue

    with open(txt_file, "r", encoding="utf-8") as infile:
        lines = [line.strip() for line in infile if line.strip()]
        if lines and lines[0].startswith("--- Page"):
            lines = lines[1:]

    page_data = [line.split("\t") for line in lines]
    if page_data:
        all_data.append({
            "page_number": page_num,
            "data": page_data
        })

if all_data:
    with open("all_structured_pages.json", "w", encoding="utf-8") as outfile:
        json.dump(all_data, outfile, indent=4)
    print("✅ All structured pages saved to all_structured_pages.json")

