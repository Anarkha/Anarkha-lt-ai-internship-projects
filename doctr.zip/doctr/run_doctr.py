from doctr.io import DocumentFile
from doctr.models import ocr_predictor

# Load image
doc = DocumentFile.from_images(r"D:\hndwrtcal-l&t\202506041452187_page1.png")

# Load OCR model
model = ocr_predictor(det_arch="db_resnet50", reco_arch="crnn_vgg16_bn", pretrained=True)

# Perform OCR
result = model(doc)

# Print recognized text
print("\n🔍 Extracted Text:")
for page in result.pages:
    for block in page.blocks:
        for line in block.lines:
            line_text = " ".join([word.value for word in line.words])
            print(line_text)
